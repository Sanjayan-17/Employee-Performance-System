
struct avl
{
    int data;
    struct avl *left;
    struct avl *right;
    int height ; 
};