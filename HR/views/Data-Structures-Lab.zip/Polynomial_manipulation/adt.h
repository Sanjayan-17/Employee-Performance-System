
struct poly
{
    int coeff,exp;
    struct poly *next;
};


