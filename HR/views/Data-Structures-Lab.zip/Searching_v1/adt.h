struct numberADT
{
    int arr[20];
    int size ;
};