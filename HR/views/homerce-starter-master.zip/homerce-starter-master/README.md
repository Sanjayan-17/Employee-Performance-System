# Typesense Workshop

Download this starter project by clicking on the green button up there 👆🏽 that says 'Code' and then click on download zip.

After extracting the .zip, open the folder on your terminal/command prompt and run `npm install` to install all the dependencies.

Then run `npm start` to start the server 🚀
