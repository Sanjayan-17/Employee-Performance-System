import "./App.css";

function App() {
  return (
    <div className="App">
      <h1 className="font-title text-6xl text-center mt-10 cursor-pointer">
        Homerce
      </h1>
      <div className="flex font-body text-2xl items-center justify-center h-screen -my-28">
        It works! You have succesfully built the website and it's live! 🚀
      </div>
    </div>
  );
}

export default App;
